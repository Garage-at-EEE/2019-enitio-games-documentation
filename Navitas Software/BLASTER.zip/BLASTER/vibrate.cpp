#include "Arduino.h"
#include "vibrate.h"

Vibrator::Vibrator()
{
}

void Vibrator::init(int pin)
{
	  _pin = pin;
	  pinMode(pin, OUTPUT);
}

void Vibrator::vibrate(int strength, int milliseconds)
{
	unsigned long current = millis();
	while((millis()-current)<=milliseconds)
	{
		analogWrite(_pin,map(strength,0,5,0,1023));
	}	
    digitalWrite(_pin,LOW);
}
