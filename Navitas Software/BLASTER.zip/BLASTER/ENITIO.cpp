//     __    __ _____  __________  ___   ____   ___  _  ___
//    /__\/\ \ \\_   \/__   \_   \/___\ |___ \ / _ \/ |/ _ \      
//   /_\ /  \/ / / /\/  / /\// /\//  //   __) | | | | | (_) |
//  //__/ /\  /\/ /_   / //\/ /_/ \_//   / __/| |_| | |\__, |
//  \__/\_\ \/\____/   \/ \____/\___/   |_____|\___/|_|  /_/
//
//       __  _        _____  _____  _    __          __  __ _____
//    /\ \ \/_\/\   /\\_   \/__   \/_\  / _\ /\   /\/__\/__\___ /
//   /  \/ //_\\ \ / / / /\/  / /\//_\\ \ \  \ \ / /_\ / \// |_ \ 
//  / /\  /  _  \ V /\/ /_   / / /  _  \_\ \  \ V //__/ _  \___) |
//  \_\ \/\_/ \_/\_/\____/   \/  \_/ \_/\__/   \_/\__/\/ \_/____/
//
//     ___   _      __    _      ___   __  ____    __  __  __
//    / _ \ /_\    /__\  /_\    / _ \ /__\/ __ \  /__\/__\/__\    
//   / /_\///_\\  / \// //_\\  / /_\//_\ / / _` |/_\ /_\ /_\      
//  / /_\\/  _  \/ _  \/  _  \/ /_\\//__| | (_| //__//__//__
//  \____/\_/ \_/\/ \_/\_/ \_/\____/\__/ \ \__,_\__/\__/\__/
//                                        \____/
/*
  <Property of Garage@EEE>
  This library is made for ENITIO 2019
  Starting Date:    2019-06-01
  Ending Date:		2019-07-11
  Name:             ENITIO.cpp
  Compiler & Maker: Ian & Andrian
*/

/*
  Library Included:
    Arduino           -> General Library
      RF24            -> from GitHub
      I2C OLED        -> from GitHub
      Vibration Motor -> Made by Ian
      IRremot + enums -> Modified by Andrian
      NeoPixel        -> from GitHub
*/

//General Header File
#include "Arduino.h"
#include "ENITIO.h"
//RF24
#include <SPI.h>
#include "RF24.h"
//NeoPixel
#include "Adafruit_NeoPixel.h"
/*
  Pin Configurations:
    Usable Pins:
      Digital D2 ~ D13
      Analog  A0 ~ A7
  Arduino Nano V3 m328p(old_bootloader) micro_usb_port:
    #NOTHING#       D2
    IR_Transmitter  D3
    OLED_RESET      D4    Joystick_Xpin     A0
    Joystick_SW     D5    Joystick_Ypin     A1
    NeoPixel_DIO    D6    Vibration_Motor   A2
    RF24_CE         D7    #NOTHING#         A3
    RF24_SCLK       D8    OLED_SDA          A4
    #NOTHING#       D9    OLED_SCL          A5
    IR_Receiver     D10   #NOTHING#         A6
    RF24_MOSI       D11   #NOTHING#         A7
    RF24_MISO       D12
    RF24_SCLK       D13
*/

//Joystick CONFIG
#define SW 5
#define SWL 3
//RF24 CONFIG
#define CE 7
#define CS 8
RF24 radio(CE, CS);
byte addresses[][6] = {"0", "1"};
int count = 0;
//NeoPixel CONFIG
#ifdef __AVR__
#include <avr/power.h>
#endif
#define PIN1 A0
#define PIN2 A1
#define PIN3 A2
#define PIN4 A3
#define NUMPIXELS 4
Adafruit_NeoPixel pixel1 = Adafruit_NeoPixel(NUMPIXELS, PIN1, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel pixel2 = Adafruit_NeoPixel(NUMPIXELS, PIN2, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel pixel3 = Adafruit_NeoPixel(NUMPIXELS, PIN3, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel pixel4 = Adafruit_NeoPixel(NUMPIXELS, PIN4, NEO_GRB + NEO_KHZ800);
//Variable for background control
#define CHANNEL11 122
#define tick 10

/*
  0:  Settings -> 100% (left)
      1. RF24 Channel <100%>
      2. Pair A Friend <100%>
      3. NeoPixel Color (ON/OFF)<100%> (Breathing Light Color in Background)
  1:  Home -> 100% (middle)
  2:  Sender -> 100% (right)
  3:  Game Mode + Player Info -> 100% (up)
  4:  AI Trainer + Check Grid -> 100% (down)
  5:  Screen ON/OFF -> 100% (press)
  6:  Boss Mode -> 100%
  **need to design the UI**
  **vibration feedback not added**
*/
//define a function for swipe actions:

ENITIO::ENITIO()
{
}
void ENITIO::initialize(unsigned long ID, int HEALTH, int MANA, int ATTACK) {
  //Pin init
  pinMode(SW, INPUT_PULLUP);
  pinMode(SWL, OUTPUT);
  digitalWrite(SWL, LOW);
  //RF24_init
  radio.begin();
  //channel frequency
  //default 50
  radio.setChannel(CHANNEL11);
  //energy level
  //must be the same for all navitas
  //either LOW, HIGH, or MAX
  radio.setPALevel(RF24_PA_MAX);
  //data rate, maximum 1MBPS
  radio.setDataRate(RF24_1MBPS);
  //default open writing channel
  radio.stopListening();
  radio.openWritingPipe(addresses[0]);
  //init NeoPixel
  pixel1.begin();
  pixel1.setPixelColor(0, 15, 15, 15);
  pixel2.begin();
  pixel2.setPixelColor(0, 15, 15, 15);
  pixel3.begin();
  pixel3.setPixelColor(0, 15, 15, 15);
  pixel4.begin();
  pixel4.setPixelColor(0, 15, 15, 15);
  pixel1.show();
  pixel2.show();
  pixel3.show();
  pixel4.show();
  delay(100);
  pixel1.setPixelColor(0, 0, 0, 0);
  pixel1.show();
  pixel2.setPixelColor(0, 0, 0, 0);
  pixel2.show();
  pixel3.setPixelColor(0, 0, 0, 0);
  pixel3.show();
  pixel4.setPixelColor(0, 0, 0, 0);
  pixel4.show();
  //Serial.begin(9600);
  randomSeed(analogRead(A5));
}
void ENITIO::host(int HEALTH, int MANA, int ATTACK) {
  if (!digitalRead(SW)) {
    delay(250);
    digitalWrite(SWL, HIGH);
    unsigned long con = millis();
    bool flag = true;
    while ( (millis() - con) <= 10000 && flag) {
      if (!digitalRead(SW)) {
        count += 1;
        delay(250);
      }
      if (count == 2) {
        flag = false;
      }
    }
  }
  if (count == 2) {
    digitalWrite(SWL, LOW);
    unsigned long current = millis();
    byte pointer = 0;
    bool flag = true;
    while (digitalRead(SW)) {
      if ((millis() - current) >= tick) {
        pixel1.setPixelColor(pointer >= 4 ? pointer - 4 : pointer, 255, 0, 0);
        pixel1.setPixelColor(pointer >= 3 ? pointer - 3 : pointer + 1, 150, 0, 0);
        pixel1.setPixelColor(pointer >= 2 ? pointer - 2 : pointer + 2, 70, 0, 0);
        pixel1.setPixelColor(pointer >= 1 ? pointer - 1 : pointer + 3, 20, 0, 0);
        pixel1.show();
        pixel2.setPixelColor(pointer >= 4 ? pointer - 4 : pointer, 0, 255,  0);
        pixel2.setPixelColor(pointer >= 3 ? pointer - 3 : pointer + 1,  0, 150, 0);
        pixel2.setPixelColor(pointer >= 2 ? pointer - 2 : pointer + 2, 0, 70, 0);
        pixel2.setPixelColor(pointer >= 1 ? pointer - 1 : pointer + 3, 0, 20, 0);
        pixel2.show();
        pixel3.setPixelColor(pointer >= 4 ? pointer - 4 : pointer, 0, 0, 255);
        pixel3.setPixelColor(pointer >= 3 ? pointer - 3 : pointer + 1, 0, 0, 150);
        pixel3.setPixelColor(pointer >= 2 ? pointer - 2 : pointer + 2, 0, 0, 70);
        pixel3.setPixelColor(pointer >= 1 ? pointer - 1 : pointer + 3, 0, 0, 20);
        pixel3.show();
        pixel4.setPixelColor(pointer >= 4 ? pointer - 4 : pointer, 255, 255, 0);
        pixel4.setPixelColor(pointer >= 3 ? pointer - 3 : pointer + 1, 150, 150, 0);
        pixel4.setPixelColor(pointer >= 2 ? pointer - 2 : pointer + 2, 70, 70, 0);
        pixel4.setPixelColor(pointer >= 1 ? pointer - 1 : pointer + 3, 20, 20, 0);
        pixel4.show();
        current = millis();
      }
      pointer++;
      if (pointer == 4) {
        pointer = 0;
      }
      char go = 'P';
      radio.write(&go, sizeof(go));
      delay(20);
    }
    delay(250);
    count = 0;
    digitalWrite(SWL, LOW);
    for (int i = 0; i <= 3; i++) {
      pixel1.setPixelColor(i, 0, 0, 0);
      pixel1.show();
      pixel2.setPixelColor(i, 0, 0, 0);
      pixel2.show();
      pixel3.setPixelColor(i, 0, 0, 0);
      pixel3.show();
      pixel4.setPixelColor(i, 0, 0, 0);
      pixel4.show();
    }
  }
}
