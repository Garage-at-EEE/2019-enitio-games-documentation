#ifndef SYSTEM5FONTx7_H
#define SYSTEMFONT5x7_H

/*
 * added to allow fontname to match header file name. 
 * as well as keep the old header filename for backward compability
 */

#define SYSTEMFONT5x7_WIDTH 5
#define SYSTEMFONT5x7_HEIGHT 7

#define SystemFont5x7 System5x7

#include "System5x7.h"

#endif
