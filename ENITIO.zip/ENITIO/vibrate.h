#ifndef vib
#define vib

class Vibrator {
  public:
    //constructor
    Vibrator();
    //initialization on pin
    void init(int pin = 5);
    //vibrate with strength and length
    void vibrate(int strength = 3, int milliseconds = 500); 
  private:
  	//private pin
    int _pin; 
  };

#endif
