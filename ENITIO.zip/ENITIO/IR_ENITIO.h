/*  IR_ENITIO.h

    This header file provides methods to simplify usage of IRremote
    library in Navitas and games.
*/

#ifndef IR_ENITIO_h
#define IR_ENITIO_h


#include "IRremote_LITE.h"  // Use the stripped down version of IRremote library.
#include "enums_ENITIO.h"   // Include list of enumerations of game instructions.

#define LEN 32        // Length of data in bits, needed by the IR_send function.
#define SENSOR_PIN 9  // Define which pin is used for the IR sensor.


// Instantiate necessary objects. NEED IRremote_LITE library!
IRsend         IR_LED;
IRrecv         IR_sensor(SENSOR_PIN);
decode_results results;


// Create an IR class.

class IR{

    public:
        IR(){
        }

        // Methods...
        void enableInput(void)
        {
            IR_sensor.enableIRIn();  // Enable the sensor.
            state = 1;
        }


        void send(uint32_t data)
        {
            IR_LED.sendNEC(data, LEN);

            if(state)
                IR_sensor.enableIRIn();  // Sending data will turn off the receiver.
                                         // Turn it back on if it was on.
        }


        int available(void)
        {
            return IR_sensor.decode(&results);
        }


        uint32_t read(void)
        {
            IR_sensor.resume();
            return results.value;
        }


    private:
        uint8_t state = 0;
};

// Create an instance called "IR" (so no need to instantiate in the sketch later).
IR IR;

#endif     // For #ifndef IR_ENITIO_h.
