//     __    __ _____  __________  ___   ____   ___  _  ___
//    /__\/\ \ \\_   \/__   \_   \/___\ |___ \ / _ \/ |/ _ \      
//   /_\ /  \/ / / /\/  / /\// /\//  //   __) | | | | | (_) |
//  //__/ /\  /\/ /_   / //\/ /_/ \_//   / __/| |_| | |\__, |
//  \__/\_\ \/\____/   \/ \____/\___/   |_____|\___/|_|  /_/
//
//       __  _        _____  _____  _    __          __  __ _____
//    /\ \ \/_\/\   /\\_   \/__   \/_\  / _\ /\   /\/__\/__\___ /
//   /  \/ //_\\ \ / / / /\/  / /\//_\\ \ \  \ \ / /_\ / \// |_ \ 
//  / /\  /  _  \ V /\/ /_   / / /  _  \_\ \  \ V //__/ _  \___) |
//  \_\ \/\_/ \_/\_/\____/   \/  \_/ \_/\__/   \_/\__/\/ \_/____/
//
//     ___   _      __    _      ___   __  ____    __  __  __
//    / _ \ /_\    /__\  /_\    / _ \ /__\/ __ \  /__\/__\/__\    
//   / /_\///_\\  / \// //_\\  / /_\//_\ / / _` |/_\ /_\ /_\      
//  / /_\\/  _  \/ _  \/  _  \/ /_\\//__| | (_| //__//__//__
//  \____/\_/ \_/\/ \_/\_/ \_/\____/\__/ \ \__,_\__/\__/\__/
//                                        \____/
/*
  <Property of Garage@EEE>
  This library is made for ENITIO 2019
  Starting Date:    2019-06-01
  Ending Date:		  2019-07-11
  Name:             ENITIO.cpp
  Compiler & Maker: Ian & Andrian
*/

/*
  Library Included:
      Arduino         -> General Library
      RF24            -> from GitHub
      I2C OLED        -> from GitHub
      Vibration Motor -> Made by Ian
      IRremote + enums-> Modified and Made by Andrian
      NeoPixel        -> from GitHub
*/

//General Header File
#include "Arduino.h"
#include "ENITIO.h"
//RF24
#include <SPI.h>
#include "RF24.h"
//OLED
#include "SSD1306Ascii.h"
#include "SSD1306AsciiAvrI2c.h"
//SD
//#include <SD.h>
//Planned to use but unfortunately no more memory
//Vibration Motor
#include "vibrate.h"
//IR
#include "IR_ENITIO.h"
#include "enums_ENITIO.h"
//NeoPixel
#include "Adafruit_NeoPixel.h"
//EEPROM
#include <EEPROM.h>
/*
  Pin Configurations:
    Usable Pins:
      Digital D2 ~ D13
      Analog  A0 ~ A7
  Arduino Nano V3 m328p(old_bootloader) micro_usb_port:
    #NOTHING#       D2
    IR_Transmitter  D3
    OLED_RESET      D4    Joystick_Xpin     A0
    Joystick_SW     D5    Joystick_Ypin     A1
    NeoPixel_DIO    D6    Vibration_Motor   A2
    RF24_CE         D7    #NOTHING#         A3
    RF24_SCLK       D8    OLED_SDA          A4
    #NOTHING#       D9    OLED_SCL          A5
    IR_Receiver     D10   #NOTHING#         A6
    RF24_MOSI       D11   #NOTHING#         A7
    RF24_MISO       D12
    RF24_SCLK       D13
*/

//OLED SCREEN CONFIG
#define I2C_ADDRESS 0x3C
#define RST_PIN 4
SSD1306AsciiAvrI2c display;
//Joystick CONFIG
#define SW 5
#define Xpin A0
#define Ypin A1
//RF24 CONFIG
#define CE 7
#define CS 8
RF24 radio(CE, CS);
byte addresses[][6] = {"0"};
//channel for wireless communication
int channel = 1;
//Wireless Communication Data && Finale Message
struct data
{
  unsigned long id = 0;
  unsigned long fid = 0;
  char text[20] = {'\0'};
  int health = 0;
  int mana = 0;
  int attack = 0;
  int progress = 100;
  int stamp[6] = {0};
};
typedef struct data message;
message Message;
//Vibrator CONFIGS
#define VIB A2
Vibrator vibrator = Vibrator();
#define strength 3
//NeoPixel CONFIG
#ifdef __AVR__
#include <avr/power.h>
#endif
#define PIN 6
#define NUMPIXELS 1
Adafruit_NeoPixel pixel = Adafruit_NeoPixel(NUMPIXELS, PIN, NEO_GRB + NEO_KHZ800);
//EEPROM CONFIG
#define ADR 0
#define RST 666
//Variable for background control
#define confirm 200
#define protect 300
#define period 100
#define first_row 0
#define second_row 8
#define third_row 16
#define fourth_row 24
#define character 5
#define passcode 126
#define RECOVER_MANA 5000
#define RECOVER_HEALTH 30000
#define HYDRA_HEALTH 5000
//RF24 Channels - double step to avoid cross over
#define CHANNEL1 100
#define CHANNEL2 102
#define CHANNEL3 104
#define CHANNEL4 106
#define CHANNEL5 108
#define CHANNEL6 112
#define CHANNEL7 114
#define CHANNEL8 116
#define CHANNEL9 118
#define CHANNEL10 120
#define CHANNEL11 122
#define CHANNEL12 124
//pointer for user's interface
int pointer = 1;
/*
   Making Progress:
  0:  Settings -> 100% (left)
      1. RF24 Channel <100%>
      2. Pair A Friend <100%>
      3. NeoPixel Color (ON/OFF)<100%> (Breathing Light Color in Background)
  1:  Home -> 100% (middle)
  2:  Sender -> 100% (right)
  3:  Game Mode + Player Info -> 100% (up)
  4:  AI Trainer + Check Grid -> 100% (down)
  5:  Screen ON/OFF -> 100% (press)
  6:  Boss Mode -> 100%
  **need to design the UI**
  **vibration feedback not added**
*/
//define a function for swipe actions:
char swipe(void);
//define a function for clan recognizing:
/*based on current plan:
  A: 40960~45055
  B: 45056~49151
  C: 49152~53247
  D: 53248~57343
*/
unsigned long now = 0;
int intensity = 0;
bool tick = true;
bool latch = true;
char clan(bool flag, bool mark, int pointer);
//define a function for interface hosting:
//variables for free input (wireless message sender
int space = 0;
int input = 65;
ENITIO::ENITIO()
{
}
void ENITIO::initialize(unsigned long ID, int HEALTH, int MANA, int ATTACK) {
  //Pin init
  pinMode(SW, INPUT_PULLUP);
  pinMode(Xpin, INPUT);
  pinMode(Ypin, INPUT);
  //init Vibrator
  vibrator.init(VIB);
  //RF24_init
  radio.begin();
  //channel frequency
  //default 50
  radio.setChannel(CHANNEL11);
  //energy level
  //must be the same for all navitas
  //either LOW, HIGH, or MAX
  radio.setPALevel(RF24_PA_MAX);
  //data rate, maximum 1MBPS
  radio.setDataRate(RF24_1MBPS);
  //default open writing & reading channel
  radio.openWritingPipe(addresses[0]);
  radio.openReadingPipe(1, addresses[0]);
  radio.startListening();
  //init NeoPixel
  pixel.begin();
  pixel.setPixelColor(0, 75, 50, 25);
  pixel.show();
  //init oled starting screen
  display.begin(&Adafruit128x64, I2C_ADDRESS, RST_PIN);
  display.setFont(newbasic3x5);
  display.clear();
  //hold for Prof Andy to begin!
  if (ID < _BOSS) {
    char go = 'F';
    //for resetting
    //EEPROM.put(RST, go);
    EEPROM.get(RST, go);
    while (go != 'P') {
      if (radio.available()) {
        while (radio.available()) {
          radio.read(&go, sizeof(go));
        }
      }
      vibrator.vibrate(1, 1);
    }
    EEPROM.put(RST, go);
  }
  radio.setChannel(CHANNEL1);
  //initializer screen
  display.setCursor(1, 0);
  display.println("     __           _ _");
  display.setCursor(1, 1);
  display.println("  /\\ \\ \\ _ __   _(_) |_ __ ___");
  display.setCursor(1, 2);
  display.println(" /  \\/ / _ \\ \\ / / | _/ _ / __|");
  display.setCursor(1, 3);
  display.println("/  /\\ | (_||\\ V /| | | (_|\\__ \\");
  display.setCursor(1, 4);
  display.println("\\_\\  \\/\\_,_| \\_/ |_|\\_\\_,_|___/");
  display.println();
  display.println("     ENITIO2019  GARAGE@EEE");
  display.print("|");
  delay(400);
  //init Gamer Info
  message upload;
  upload.id = ID;
  upload.health = HEALTH;
  upload.mana = MANA;
  upload.attack = ATTACK;
  EEPROM.get(ADR, Message);
  if (Message.id != upload.id) {
    for (int i = 0 ; i < EEPROM.length() ; i++) {
      EEPROM.write(i, 0);
    }
    EEPROM.put(ADR, upload);
    EEPROM.get(ADR, Message);
    EEPROM.put(RST, 'P');
  } else {
    EEPROM.get(ADR, Message);
  }
  randomSeed(analogRead(A5));
  for (int i = 0; i <= 29; i++) {
    display.setInvertMode(true);
    display.print(" ");
    delay(random(50, 300));
  }
  display.setInvertMode(false);
  display.print("|");
  delay(400);
  display.clear();
  //init oled operation screen
  display.begin(&Adafruit128x32, I2C_ADDRESS, RST_PIN);
  display.setFont(System5x7);
  display.setCursor(0, 0);
  display.setContrast(255);
  //init IR
  IR.enableInput();
}
void ENITIO::host(int HEALTH, int MANA, int ATTACK) {
  switch (pointer) {
    case 0: {
        // SETTINGS
        display.setCursor(7 * character, first_row);
        display.println("-SETTINGS-");
        while (digitalRead(SW)) {
          display.setCursor(0, second_row);
          display.print("[RF24 CHANNEL]:    " + (channel >= 10 ? String(channel) : ("0" + String(channel))));
          if (swipe() == 'u') {
            //set channel
            channel++;
            if (channel == 13) {
              channel = 1;
            }
            delay(protect);
          }
          if (swipe() == 'd') {
            //set channel
            channel--;
            if (channel == 0) {
              channel = 12;
            }
            delay(protect);
          }
          vibrator.vibrate(1, 1);
        }
        display.setCursor(0, second_row);
        display.println("<RF24 CHANNEL>:    " + (channel >= 10 ? String(channel) : ("0" + String(channel))));
        delay(protect);
        bool add_a_friend[2] = {0};
        while (digitalRead(SW)) {
          display.setCursor(0, third_row);
          display.print("[PAIR A FRIEND?]->" + String(add_a_friend[0] ? "YES" : " NO"));
          if (swipe() == 'u' || swipe() == 'd') {
            add_a_friend[0] = true - add_a_friend[0];
            delay(protect);
          }
          vibrator.vibrate(1, 1);
        }
        delay(protect);
        while (add_a_friend[0] && digitalRead(SW)) {
          display.setCursor(0, third_row);
          display.print("[ADDING ROLE]:" + String(add_a_friend[1] ? "   SEND" : "RECEIVE"));
          if (swipe() == 'u') {
            add_a_friend[1] = true;
            delay(protect);
          }
          if (swipe() == 'd') {
            add_a_friend[1] = false;
            delay(protect);
          }
          vibrator.vibrate(1, 1);
        }
        Message.fid = 0;
        if (add_a_friend[0]) {
          delay(protect);
          display.setCursor(0, third_row);
          display.print(" ADDING YOUR FRIEND! ");
          if (add_a_friend[1]) {
            unsigned long current = millis();
            bool flag = true;
            bool flag2 = true;
            while ((millis() - current) <= 750) {
              delay(100);
              if (flag) {
                delay(100);
                IR.send(Message.id);
                delay(100);
                IR.send(Message.id);
                flag = false;
              }
              delay(100);
              if (flag2) {
                delay(100);
                IR.send(Message.id);
                delay(100);
                IR.send(Message.id);
                flag2 = false;
              }
            }
            current = millis();
            while ((millis() - current) <= 750) {
              if (IR.available()) {
                Message.fid = IR.read();
                if (Message.fid > 57343) {
                  Message.fid = 0;
                }
              }
            }
          }
          if (!add_a_friend[1]) {
            unsigned long current = millis();
            while ((millis() - current) <= 750) {
              if (IR.available()) {
                Message.fid = IR.read();
                if (Message.fid > 57343) {
                  Message.fid = 0;
                }
              }
            }
            current = millis();
            bool flag = true;
            bool flag2 = true;
            while ((millis() - current) <= 750) {
              delay(100);
              if (flag) {
                delay(100);
                IR.send(Message.id);
                delay(100);
                IR.send(Message.id);
                flag = false;
              }
              delay(100);
              if (flag2) {
                delay(100);
                IR.send(Message.id);
                delay(100);
                IR.send(Message.id);
                flag2 = false;
              }
            }
          }
          if (Message.fid == 0) {
            add_a_friend[0] = false;
            display.clear(0, 128, 2, 2);
            display.setCursor(9.5 * character, fourth_row);
            display.print("FAILED");
            delay(protect * 5);
          } else {
            display.setCursor(0, fourth_row);
            String id1 = String(Message.fid, HEX);
            id1.toUpperCase();
            display.print("[FRIEND ID]:     " + id1);
            delay(protect * 6);
          }
        }
        display.setCursor(0, third_row);
        display.println("<PAIR A FRIEND?>->" + String(add_a_friend[0] ? "YES" : " NO"));
        delay(protect);
        while (digitalRead(SW)) {
          display.setCursor(0, fourth_row);
          display.print("[BREATHING LED]:  " + String(latch ? " ON" : "OFF"));
          if (swipe() == 'u' || swipe() == 'd') {
            latch = true - latch;
            delay(protect);
          }
          vibrator.vibrate(1, 1);
        }
        display.setCursor(0, fourth_row);
        display.print("<BREATHING LED>:  " + String(latch ? " ON" : "OFF"));
        int ch = 0;
        switch (channel) {
          case 1: {
              ch = CHANNEL1;
              break;
            }
          case 2: {
              ch = CHANNEL2;
              break;
            }
          case 3: {
              ch = CHANNEL3;
              break;
            }
          case 4: {
              ch = CHANNEL4;
              break;
            }
          case 5: {
              ch = CHANNEL5;
              break;
            }
          case 6: {
              ch = CHANNEL6;
              break;
            }
          case 7: {
              ch = CHANNEL7;
              break;
            }
          case 8: {
              ch = CHANNEL8;
              break;
            }
          case 9: {
              ch = CHANNEL9;
              break;
            }
          case 10: {
              ch = CHANNEL10;
              break;
            }
          case 11: {
              ch = CHANNEL11;
              break;
            }
          case 12: {
              ch = CHANNEL12;
              break;
            }
        }
        radio.setChannel(ch);
        //radio.openReadingPipe(1, addresses[0]);
        radio.startListening();
        vibrator.vibrate(strength, period);
        delay(protect * 4);
        pointer = 1;
        display.clear();
        EEPROM.put(ADR, Message);
        break;
      }
    case 1: {
        // HOME
        display.setCursor(9.5 * character, 0);
        display.println("-HOME-");
        display.println("<RF24 CHANNEL>:    " + (channel >= 10 ? String(channel) : ("0" + String(channel))));
        display.setCursor(0, third_row);
        String id1 = String(Message.id, HEX);
        id1.toUpperCase();
        display.print("*WELCOME BACK! #" + id1 + "*");
        if (radio.available())
        {
          unsigned long temp = Message.id;
          unsigned long temp2 = Message.fid;
          unsigned long temp3 = Message.health;
          unsigned long temp4 = Message.mana;
          unsigned long temp5 = Message.attack;
          unsigned long temp6 = Message.progress;
          while (radio.available())
          {
            radio.read(&Message, sizeof(Message));
          }
          vibrator.vibrate(strength, period);
          unsigned long current = millis();
          bool flag = true;
          if (Message.id == temp2 || temp2 == 0 || Message.id >= _BOSS) {
            while ((millis() - current) <= 2000) {
              if (flag) {
                display.setCursor(0, third_row);
                String id1 = String(Message.id, HEX);
                id1.toUpperCase();
                display.println("MESSAGE FROM:  " + ((Message.id == temp2) ? "FRIEND" : (" " + String(Message.id >= 57344 ? "HYDRA" : (" " + id1)))));
                display.println(channel == 12 ? "  A COMMAND IS SENT  " : Message.text);
                //              for (int i = 0; i <= 19; i++) {
                //                Message.text[i] = '\0';
                //              }
                space = 0;
                for (int i = 0; i <= sizeof(Message.text); i++) {
                  if (Message.text[i] != '\0') {
                    space++;
                  } else break;
                }
                flag = false;
              }
            }
          }
          Message.id = temp;
          Message.fid = temp2;
          Message.health = temp3;
          Message.mana = temp4;
          Message.attack = temp5;
          Message.progress = temp6;
          display.clear();
        }

        if (swipe() == 'r') {
          //confirm screen
          delay(confirm);
          if (swipe() == 'r') {
            pointer = 2;
            display.clear();
            radio.stopListening();
            //radio.openWritingPipe(addresses[0]);
            vibrator.vibrate(strength, period);
            delay(protect);
          }
        }
        if (swipe() == 'l') {
          //confirm screen
          delay(confirm);
          if (swipe() == 'l') {
            pointer = 0;
            display.clear();
            vibrator.vibrate(strength, period);
            delay(protect);
          }
        }
        if (swipe() == 'u') {
          //confirm screen
          delay(confirm);
          if (swipe() == 'u') {
            pointer = 3;
            display.clear();
            vibrator.vibrate(strength, period);
            delay(protect);
          }
        }
        if (swipe() == 'd') {
          //confirm screen
          delay(confirm);
          if (swipe() == 'd') {
            pointer = 4;
            display.clear();
            vibrator.vibrate(strength, period);
            delay(protect);
          }
        }
        if (!digitalRead(SW)) {
          delay(confirm);
          if (!digitalRead(SW)) {
            delay(confirm);
            if (!digitalRead(SW)) {
              delay(confirm * 13);
              if (!digitalRead(SW)) {
                pointer = 5;
                vibrator.vibrate(strength, period);
              }
            }
          }
        }
        Message.attack = (int)((double)ATTACK * ((double)Message.progress / 100)) >= 1 ? (int)((double)ATTACK * ((double)Message.progress / 100)) : 1;
        if (Message.attack > 7) {
          Message.attack = 7;
        }
        break;
      }
    case 2: {
        // RF24 SENDER
        if (channel != 12) {
          vibrator.vibrate(1, 1);
          display.setCursor(0, first_row);
          display.println("-RF24 MESSAGE SENDER-");
          display.println("UP/DOWN/CLICK:  INPUT");
          display.println("RIGHT/LEFT: SEND/EXIT");
          display.setCursor(0, fourth_row);
          int curs = 0;
          for (int i = 0; i < (sizeof(Message.text) - 1); i++) {
            if (Message.text[i] != '\0') {
              display.print(char(Message.text[i]));
              curs += 6;
              display.setCursor(curs, fourth_row);
            } else break;
          }
          if (swipe() == 'u') {
            input++;
            delay(protect);
          } else if (swipe() == 'd') {
            input--;
            delay(protect);
          }
          if (input == 31) {
            input = 126;
          } else if (input == 127) {
            input = 32;
          }
          display.setInvertMode(true);
          display.setCursor(curs, fourth_row);
          display.print(char(input));
          //confirm input character
          if (!digitalRead(SW)) {
            //confirm screen
            Message.text[space] = input;
            if (space >= (sizeof(Message.text) - 1)) {
              vibrator.vibrate(strength, period);
            } else {
              space += 1;
              Message.text[space] = '\0';
            }
            delay(protect);
          }
          if (swipe() == 'r') {
            delay(confirm * 2);
            if (swipe() == 'r') {
              radio.write(&Message, sizeof(Message));
              pixel.setPixelColor(0, 0, 100, 0);
              pixel.show();
              vibrator.vibrate(strength, period);
            }
            for (int i = 0; i <= 19; i++) {
              Message.text[i] = '\0';
            }
            space = 0;
            input = 65;
            display.clear(0, 25 * character, 3, 3);
          }
          if (swipe() == 'l') {
            //confirm screen
            delay(confirm);
            if (swipe() == 'l') {
              pointer = 1;
              display.clear();
              //radio.openReadingPipe(1, addresses[0]);
              radio.startListening();
            }
          }
        } else {
          if (clan(false, true, pointer) != 'H') {
            display.setCursor(0, first_row);
            display.println("-DEMOCRAZY GAME CTRL-");
            display.println("SWIPE: DIRECTION VOTE");
            display.println("CLICK/HOLD: SEND/EXIT");
            display.setCursor(0, fourth_row);
            display.print("DIRECTION:");
            switch (swipe()) {
              case 'u': {
                  display.clear(13 * character, 22 * character, 3, 3);
                  display.print("FRONT");
                  Message.text[0] = 'u';
                  delay(protect);
                  break;
                }
              case 'd': {
                  display.clear(13 * character, 22 * character, 3, 3);
                  display.print("BACK");
                  Message.text[0] = 'd';
                  delay(protect);
                  break;
                }
              case 'l': {
                  display.clear(13 * character, 22 * character, 3, 3);
                  display.print("LEFT");
                  Message.text[0] = 'l';
                  delay(protect);
                  break;
                }
              case 'r': {
                  display.clear(13 * character, 22 * character, 3, 3);
                  display.print("RIGHT");
                  Message.text[0] = 'r';
                  delay(protect);
                  break;
                }
            }
            if (!digitalRead(SW)) {
              radio.write(&Message, sizeof(Message));
              vibrator.vibrate(strength, period);
              delay(protect * 5);
              if (!digitalRead(SW)) {
                pointer = 1;
                Message.text[0] = '\0';
                space = 0;
                input = 32;
                EEPROM.put(ADR, Message);
                display.clear();
                //radio.openReadingPipe(1, addresses[0]);
                radio.startListening();
              }
            }
          } else {
            display.setCursor(0, first_row);
            display.println("-DEMOCRAZY GAME CTRL-");
            display.println("SWIPE: DIRECTION VOTE");
            display.println("CLICK/HOLD: SEND/EXIT");
            display.setCursor(0, fourth_row);
            display.print("COMMAND: ");
            switch (swipe()) {
              case 'u': {
                  display.clear(11 * character, 22 * character, 3, 3);
                  display.print("STOP");
                  Message.text[0] = 't';
                  delay(protect);
                  break;
                }
              case 'd': {
                  display.clear(11 * character, 22 * character, 3, 3);
                  display.print("RESUME");
                  Message.text[0] = 's';
                  delay(protect);
                  break;
                }
            }
            if (!digitalRead(SW)) {
              radio.write(&Message, sizeof(Message));
              delay(500);
              if (!digitalRead(SW)) {
                pointer = 1;
                Message.text[0] = '\0';
                space = 0;
                input = 32;
                display.clear();
                //radio.openReadingPipe(1, addresses[0]);
                radio.startListening();
              }
            }
          }

        }
        display.setInvertMode(false);
        break;
      }
    case 3: {
        // BATTLE MODE
        display.setCursor(0, first_row);
        String id1 = String(Message.id, HEX);
        id1.toUpperCase();
        String id2 = String(Message.fid, HEX);
        id2.toUpperCase();
        display.println("PLAYER ID: " + id1);
        display.println("FRIEND ID: " + String(Message.fid ? id2 : "NOT PAIRED"));
        clan(true, false, pointer);
        while (digitalRead(SW)) {
          bool mode1 = false;
          while (digitalRead(SW)) {
            vibrator.vibrate(1, 1);
            display.setCursor(0, fourth_row);
            display.print("BATTLE MODE:" + String(mode1 ? "   FINALE" : "  SWITCH!"));
            if (swipe() == 'u' || swipe() == 'd') {
              mode1 = true - mode1;
              delay(protect);
            }
          }
          delay(protect);
          display.println();
          if (mode1) {
            //enter passcode
            int tick = 32;
            while (digitalRead(SW)) {
              vibrator.vibrate(1, 1);
              display.setCursor(0, fourth_row);
              display.print("<PASSCODE>: " + String(char(tick)));
              if (swipe() == 'u') {
                tick++;
                if (tick == 127) {
                  tick = 32;
                }
                delay(protect);
              }
              if (swipe() == 'd') {
                tick--;
                if (tick == 31) {
                  tick = 126;
                }
                delay(protect);
              }
            }
            delay(protect);
            display.clear();
            if (tick == passcode) {
              display.setCursor(3.5 * character, first_row);
              display.println("PASSCODE CORRECT!");
              delay(protect * 5);
              display.clear();
              unsigned long mana_tick = millis();
              unsigned long health_tick = millis();
              while (digitalRead(SW)) {
                vibrator.vibrate(1, 1);
                display.setCursor(4 * character, first_row);
                display.println("-ENITIO FINALE-");
                //display icon instead of numbers
                display.print("<HEALTH>: ");
                for (int i = 0; i <= 9; i++) {
                  display.setCursor((12 + i * 2)*character, second_row);
                  display.setLetterSpacing(2);
                  if (i <= (Message.health - 1)) {
                    display.setInvertMode(true);
                    display.print("*");
                  } else {
                    display.setInvertMode(false);
                    display.print(" ");
                  }
                }
                display.println();
                display.setLetterSpacing(1);
                display.print("< MANA >: ");
                for (int i = 0; i <= 9; i++) {
                  display.setCursor((12 + i * 2)*character, third_row);
                  display.setLetterSpacing(2);
                  if (i <= (Message.mana - 1)) {
                    display.setInvertMode(true);
                    display.print("*");
                  } else {
                    display.setInvertMode(false);
                    display.print(" ");
                  }
                }
                display.println();
                display.setLetterSpacing(1);
                display.print("<ATTACK>: ");
                for (int i = 0; i <= 9; i++) {
                  display.setCursor((12 + i * 2)*character, fourth_row);
                  display.setLetterSpacing(2);
                  if (i <= (Message.attack - 1)) {
                    display.setInvertMode(true);
                    display.print("*");
                  } else {
                    display.setInvertMode(false);
                    display.print(" ");
                  }
                }
                display.setLetterSpacing(1);
                if (swipe() == 'u' && Message.mana > 0 && Message.health > 0) {
                  if (clan(false, true, pointer) != 'H') {
                    switch (clan(false, true, pointer)) {
                      case 'R': {
                          IR.send(NAVITAS_ATTACK + _RED);
                          Message.mana--;
                          EEPROM.put(ADR, Message);
                          break;
                        }
                      case 'G': {
                          IR.send(NAVITAS_ATTACK + _GREEN);
                          Message.mana--;
                          EEPROM.put(ADR, Message);
                          break;
                        }
                      case 'B': {
                          IR.send(NAVITAS_ATTACK + _BLUE);
                          Message.mana--;
                          EEPROM.put(ADR, Message);
                          break;
                        }
                      case 'Y': {
                          IR.send(NAVITAS_ATTACK + _YELLOW);
                          Message.mana--;
                          EEPROM.put(ADR, Message);
                          break;
                        }
                    }
                  } else {
                    IR.send(NAVITAS_KILL);
                  }
                  //Neopixel se
                  pixel.setPixelColor(0, 0, 25, 25);
                  pixel.show();
                  delay(protect);
                  vibrator.vibrate(strength, period);
                }
                if (swipe() == 'd' && Message.mana > 0 && Message.health > 0) {
                  switch (clan(false, true, pointer)) {
                    case 'R': {
                        IR.send(NAVITAS_CLAIM + _RED + Message.attack);
                        Message.mana--;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                    case 'G': {
                        IR.send(NAVITAS_CLAIM + _GREEN + Message.attack);
                        Message.mana--;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                    case 'B': {
                        IR.send(NAVITAS_CLAIM + _BLUE + Message.attack);
                        Message.mana--;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                    case 'Y': {
                        IR.send(NAVITAS_CLAIM + _YELLOW + Message.attack);
                        Message.mana--;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                    case'H': {
                        IR.send(NAVITAS_DESTROY);
                      }
                  }
                  //Neopixel se
                  pixel.setPixelColor(0, 0, 25, 25);
                  pixel.show();
                  delay(protect);
                  vibrator.vibrate(strength, period);
                }
                //Neopixel display health
                if (Message.health > (int)(HEALTH * 2 / 3)) {
                  pixel.setPixelColor(0, 0, 50, 0);
                  pixel.show();
                } else if (Message.health > (int)(HEALTH / 3)) {
                  pixel.setPixelColor(0, 25, 25, 0);
                  pixel.show();
                } else {
                  pixel.setPixelColor(0, 50, 0, 0);
                  pixel.show();
                  if (Message.health == 0) {
                    vibrator.vibrate(strength, period);
                  }
                }
                //IR Actions: Attack, Claim, Kill, Heal, Charge
                if (IR.available() && clan(false, true, pointer) != 'H') {
                  unsigned long temp = IR.read();
                  if (temp >= NAVITAS_ATTACK && temp <= NAVITAS_KILL) {
                    if (temp == NAVITAS_KILL) {
                      Message.health = 0;
                      Message.mana = 0;
                    } else {
                      temp -= NAVITAS_ATTACK;
                      switch (temp) {
                        case _RED: {
                            if (clan(false, true, pointer) != 'R') {
                              if (Message.health > 0) {
                                Message.health--;
                              }
                              EEPROM.put(ADR, Message);
                            }
                            break;
                          }
                        case _GREEN: {
                            if (clan(false, true, pointer) != 'G') {
                              if (Message.health > 0) {
                                Message.health--;
                              }
                              EEPROM.put(ADR, Message);
                            }
                            break;
                          }
                        case _BLUE: {
                            if (clan(false, true, pointer) != 'B') {
                              if (Message.health > 0) {
                                Message.health--;
                              }
                              EEPROM.put(ADR, Message);
                            }
                            break;
                          }
                        case _YELLOW: {
                            if (clan(false, true, pointer) != 'Y') {
                              if (Message.health > 0) {
                                Message.health--;
                              }
                              EEPROM.put(ADR, Message);
                            }
                            break;
                          }
                      }
                    }
                  } else {
                    switch (temp) {
                      case TOWERS_HEAL: {
                          Message.health = HEALTH;
                          EEPROM.put(ADR, Message);
                          break;
                        }
                      case TOWERS_CHARGE: {
                          Message.mana = MANA;
                          EEPROM.put(ADR, Message);
                          break;
                        }
                      case TOWERS_KILL: {
                          Message.health = 0;
                          Message.mana = 0;
                          EEPROM.put(ADR, Message);
                          break;
                        }
                    }
                  }
                }
                //Self Healing
                if (Message.mana < MANA && (millis() - mana_tick) >= RECOVER_MANA) {
                  Message.mana++;
                  mana_tick = millis();
                  EEPROM.put(ADR, Message);
                } else if (Message.mana == MANA) {
                  mana_tick = millis();
                }
                if (Message.health <= 0 && (millis() - health_tick) >= RECOVER_HEALTH && clan(false, true, pointer) != 'H') {
                  Message.health++;
                  health_tick = millis();
                  EEPROM.put(ADR, Message);
                } else if ((millis() - health_tick) >= HYDRA_HEALTH && clan(false, true, pointer) == 'H') {
                  Message.health++;
                  health_tick = millis();
                  EEPROM.put(ADR, Message);
                } else if (Message.health == HEALTH) {
                  health_tick = millis();
                }
              }
            }
            else {
              display.clear();
              display.setCursor(0, first_row);
              display.println("PASSCODE INCORRECT!");
              display.println("ACTIVATE SWITCH! MODE");
              delay(protect * 5);
              display.clear();
              while (digitalRead(SW)) {
                vibrator.vibrate(1, 1);
                display.setCursor(8 * character, first_row);
                display.println("-SWITCH!-");
                display.print("< MANA >: ");
                for (int i = 0; i <= 9; i++) {
                  display.setCursor((12 + i * 2)*character, third_row);
                  display.setLetterSpacing(2);
                  if (i <= (Message.mana - 1)) {
                    display.setInvertMode(true);
                    display.print("*");
                  } else {
                    display.setInvertMode(false);
                    display.print(" ");
                  }
                }
                display.println();
                display.setLetterSpacing(1);
                display.print("<ATTACK>: ");
                for (int i = 0; i <= 9; i++) {
                  display.setCursor((12 + i * 2)*character, fourth_row);
                  display.setLetterSpacing(2);
                  if (i <= (Message.attack - 1)) {
                    display.setInvertMode(true);
                    display.print("*");
                  } else {
                    display.setInvertMode(false);
                    display.print(" ");
                  }
                }
                display.setLetterSpacing(1);
                if (swipe() == 'd' && Message.mana > 0) {
                  switch (clan(false, true, pointer)) {
                    case 'R': {
                        IR.send(NAVITAS_CLAIM + _RED + Message.attack);
                        Message.mana--;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                    case 'G': {
                        IR.send(NAVITAS_CLAIM + _GREEN + Message.attack);
                        Message.mana--;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                    case 'B': {
                        IR.send(NAVITAS_CLAIM + _BLUE + Message.attack);
                        Message.mana--;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                    case 'Y': {
                        IR.send(NAVITAS_CLAIM + _YELLOW + Message.attack);
                        Message.mana--;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                    case'H': {
                        IR.send(NAVITAS_DESTROY);
                      }
                  }
                  //Neopixel se
                  pixel.setPixelColor(0, 0, 25, 25);
                  pixel.show();
                  delay(protect);
                  vibrator.vibrate(strength, period);
                }
                //Neopixel display health
                if (Message.mana > (int)(MANA * 2 / 3)) {
                  pixel.setPixelColor(0, 0, 50, 0);
                  pixel.show();
                } else if (Message.mana > (int)(MANA / 3)) {
                  pixel.setPixelColor(0, 25, 25, 0);
                  pixel.show();
                } else {
                  pixel.setPixelColor(0, 50, 0, 0);
                  pixel.show();
                }
                //IR Actions: Attack, Claim, Kill, Heal, Charge
                if (IR.available()) {
                  unsigned long temp = IR.read();
                  switch (temp) {
                    case TOWERS_HEAL: {
                        Message.health = HEALTH;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                    case TOWERS_CHARGE: {
                        Message.mana = MANA;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                    case TOWERS_KILL: {
                        Message.health = 0;
                        Message.mana = 0;
                        EEPROM.put(ADR, Message);
                        break;
                      }
                  }
                }
              }
            }
          } else {
            display.clear();
            display.setCursor(0, first_row);
            display.println("ACTIVATE SWITCH! MODE");
            delay(protect * 5);
            display.clear();
            while (digitalRead(SW)) {
              vibrator.vibrate(1, 1);
              display.setCursor(8 * character, first_row);
              display.println("-SWITCH!-");
              display.print("< MANA >: ");
              for (int i = 0; i <= 9; i++) {
                display.setCursor((12 + i * 2)*character, third_row);
                display.setLetterSpacing(2);
                if (i <= (Message.mana - 1)) {
                  display.setInvertMode(true);
                  display.print("*");
                } else {
                  display.setInvertMode(false);
                  display.print(" ");
                }
              }
              display.println();
              display.setLetterSpacing(1);
              display.print("<ATTACK>: ");
              for (int i = 0; i <= 9; i++) {
                display.setCursor((12 + i * 2)*character, fourth_row);
                display.setLetterSpacing(2);
                if (i <= (Message.attack - 1)) {
                  display.setInvertMode(true);
                  display.print("*");
                } else {
                  display.setInvertMode(false);
                  display.print(" ");
                }
              }
              display.setLetterSpacing(1);
              if (swipe() == 'd' && Message.mana > 0) {
                switch (clan(false, true, pointer)) {
                  case 'R': {
                      IR.send(NAVITAS_CLAIM + _RED + Message.attack);
                      Message.mana--;
                      EEPROM.put(ADR, Message);
                      break;
                    }
                  case 'G': {
                      IR.send(NAVITAS_CLAIM + _GREEN + Message.attack);
                      Message.mana--;
                      EEPROM.put(ADR, Message);
                      break;
                    }
                  case 'B': {
                      IR.send(NAVITAS_CLAIM + _BLUE + Message.attack);
                      Message.mana--;
                      EEPROM.put(ADR, Message);
                      break;
                    }
                  case 'Y': {
                      IR.send(NAVITAS_CLAIM + _YELLOW + Message.attack);
                      Message.mana--;
                      EEPROM.put(ADR, Message);
                      break;
                    }
                  case'H': {
                      IR.send(NAVITAS_DESTROY);
                    }
                }
                //Neopixel se
                pixel.setPixelColor(0, 0, 25, 25);
                pixel.show();
                delay(protect);
                vibrator.vibrate(strength, period);
              }
              //Neopixel display health
              if (Message.mana > (int)(MANA * 2 / 3)) {
                pixel.setPixelColor(0, 0, 50, 0);
                pixel.show();
              } else if (Message.mana > (int)(MANA / 3)) {
                pixel.setPixelColor(0, 25, 25, 0);
                pixel.show();
              } else {
                pixel.setPixelColor(0, 50, 0, 0);
                pixel.show();
              }
              //IR Actions: Attack, Claim, Kill, Heal, Charge
              if (IR.available()) {
                unsigned long temp = IR.read();
                switch (temp) {
                  case TOWERS_HEAL: {
                      Message.health = HEALTH;
                      EEPROM.put(ADR, Message);
                      break;
                    }
                  case TOWERS_CHARGE: {
                      Message.mana = MANA;
                      EEPROM.put(ADR, Message);
                      break;
                    }
                  case TOWERS_KILL: {
                      Message.health = 0;
                      Message.mana = 0;
                      EEPROM.put(ADR, Message);
                      break;
                    }
                }
              }
            }
          }
        }
        display.clear();
        delay(protect);
        pointer = 1;
        break;
      }
    case 4: {
        // ATTACK ENHANCEMENT SYSTEM
        if (clan(false, true, pointer) != 'H') {
          unsigned long header = pow(2, 20) + random(0, 2) * pow(2, 19) + random(0, 2) * pow(2, 18) + random(0, 2) * pow(2, 17);
          int progress = Message.progress;
          if (Message.stamp[5] != 0) {
            progress -= Message.stamp[5] * 10;
          }
          bool one = progress % 2;
          bool two = (int)(progress / 2) % 2;
          bool three = (int)(progress / 2 / 2) % 2;
          bool four = (int)(progress / 2 / 2 / 2) % 2;
          bool five = (int)(progress / 2 / 2 / 2 / 2) % 2;
          bool six = (int)(progress / 2 / 2 / 2 / 2 / 2) % 2;
          bool seven = (int)(progress / 2 / 2 / 2 / 2 / 2 / 2) % 2;
          unsigned long percent = seven * pow(2, 16) + six * pow(2, 15) + five * pow(2, 14) + four * pow(2, 13) + three * pow(2, 12) + two * pow(2, 11) + one * pow(2, 10);
          //encoder
          unsigned long range = 941;
          while (digitalRead(SW)) {
            vibrator.vibrate(1, 1);
            display.setCursor(0, first_row);
            String id1 = String(Message.id, HEX);
            id1.toUpperCase();
            display.println("PLAYER ID: " + id1);
            clan(true, false, pointer);
            display.println("ATK ENHANCEMENT: " + String((Message.progress >= 10 ? ( Message.progress >= 100 ? Message.progress : (" " + String(Message.progress))) : (" 0" + String(Message.progress)))) + "%");
            display.println("SECRET CODE:" + ((Message.stamp[0] && Message.stamp[1] && Message.stamp[2] && Message.stamp[3] && Message.stamp[4]) ? ("  " + String((unsigned long)(header + percent + range))) : String("?????????")));
            if (IR.available()) {
              unsigned long temp = IR.read();
              if (temp >= _DEMOCRAZY && temp < _TICTACWORD) {
                temp -= _DEMOCRAZY;
                Message.stamp[0] = temp;
              } else if (temp >= _TICTACWORD && temp < _SWITCH) {
                temp -= _TICTACWORD;
                Message.stamp[1] = temp;
              } else if (temp >= _SWITCH && temp < _PIANO) {
                temp -= _SWITCH;
                Message.stamp[2] = temp;
              } else if (temp >= _PIANO && temp < _ESCAPE) {
                temp -= _PIANO;
                Message.stamp[3] = temp;
              } else if (temp >= _ESCAPE && temp < _BONUS) {
                temp -= _ESCAPE;
                Message.stamp[4] = temp;
              } else if (temp >= _BONUS && temp < _ROOF) {
                temp -= _BONUS;
                Message.stamp[5] = temp;
              }
              EEPROM.put(ADR, Message);
            }
            Message.progress = (int)(Message.stamp[0] + Message.stamp[1] + Message.stamp[2] + Message.stamp[3] + Message.stamp[4]) * 2 + Message.stamp[5] * 10;
          }
          display.clear();
          delay(protect);
          pointer = 1;
        } else {
          display.clear();
          delay(protect);
          int points = 0;
          display.setCursor(0, first_row);
          display.println("- GAME MASTERS MODE -");
          display.println("UP/DOWN/CLICK:  INPUT");
          display.println("RIGHT/PRESS:SEND/EXIT");
          display.setCursor(0, fourth_row);
          display.print("MODE: ");
          int mode = 1;
          unsigned long base = 0;
          while (digitalRead(SW)) {
            vibrator.vibrate(1, 1);
            if (swipe() == 'u') {
              display.clear(7 * character, 23 * character, 3, 3);
              mode++;
              if (mode == 7) mode = 1;
              switch (mode) {
                case 1: {
                    display.print("DEMOCRAZY");
                    base = _DEMOCRAZY;
                    break;
                  }
                case 2: {
                    display.print("TICTACWORD");
                    base = _TICTACWORD;
                    break;
                  }
                case 3: {
                    display.print("SWITCH!");
                    base = _SWITCH;
                    break;
                  }
                case 4: {
                    display.print("PIANO & PRE-F");
                    base = _PIANO;
                    break;
                  }
                case 5: {
                    display.print("ESCAPE ROOM");
                    base = _ESCAPE;
                    break;
                  }
                case 6: {
                    display.print("BONUS");
                    base = _BONUS;
                    break;
                  }
              }
              delay(protect);
            }
            if (swipe() == 'd') {
              display.clear(7 * character, 23 * character, 3, 3);
              mode--;
              if (mode == 0) mode = 6;
              switch (mode) {
                case 1: {
                    display.print("DEMOCRAZY");
                    base = _DEMOCRAZY;
                    break;
                  }
                case 2: {
                    display.print("TICTACWORD");
                    base = _TICTACWORD;
                    break;
                  }
                case 3: {
                    display.print("SWITCH!");
                    base = _SWITCH;
                    break;
                  }
                case 4: {
                    display.print("PIANO & PRE-F");
                    base = _PIANO;
                    break;
                  }
                case 5: {
                    display.print("ESCAPE ROOM");
                    base = _ESCAPE;
                    break;
                  }
                case 6: {
                    display.print("BONUS");
                    base = _BONUS;
                    break;
                  }
              }
              delay(protect);
            }
          }
          delay(protect);
          display.clear(0, 22 * character, 3, 3);
          while (digitalRead(SW)) {
            vibrator.vibrate(1, 1);
            display.setCursor(0, fourth_row);
            display.print("POINTS GIVEN:   " + String((points == 10) ? points : ("0" + String(points))) + "/10");
            switch (swipe()) {
              case 'u': {
                  points++;
                  if (points == 11) {
                    points = 0;
                  }
                  delay(protect);
                  break;
                }
              case'd': {
                  points--;
                  if (points == -1) {
                    points = 10;
                  }
                  delay(protect);
                  break;
                }
              case'r': {
                  IR.send(base + points);
                  vibrator.vibrate(strength, period);
                  delay(protect);
                  break;
                }
            }
          }
          display.clear();
          pointer = 1;
          delay(protect);
        }
        break;
      }
    case 5: {
        // POWER SAVER MODE
        display.clear();
        if (!digitalRead(SW)) {
          delay(confirm * 15);
          if (!digitalRead(SW)) {
            pointer = 1;
          }
        }
        break;
      }
  }
  clan(false, false, pointer);
  // drain enough current to make sure power bank works...
  vibrator.vibrate(1, 1);
}
char swipe(void) {
  if (map(analogRead(Ypin), 0, 1023, 50, -50) <= -45 && abs(map(analogRead(Xpin), 0, 1023, -50, 50)) <= 45) {
    return 'd';//down
  } else if (map(analogRead(Ypin), 0, 1023, 50, -50) >= 45 && abs(map(analogRead(Xpin), 0, 1023, -50, 50)) <= 45) {
    return 'u';//up
  } else if (map(analogRead(Xpin), 0, 1023, -50, 50) <= -45 && abs(map(analogRead(Ypin), 0, 1023, 50, -50)) <= 45) {
    return 'r';//left
  } else if (map(analogRead(Xpin), 0, 1023, -50, 50) >= 45 && abs(map(analogRead(Ypin), 0, 1023, 50, -50)) <= 45) {
    return 'l';//right
  } else return 'n';
}
char clan(bool flag, bool mark, int pointer) {
  if (pointer == 2) {
    if ((millis() - now) >= 100) {
      pixel.setPixelColor(0, 75, 50, 25);
      pixel.show();
      now = millis();
    }
    return '\0';
  } else {
    int GRP = 0;
    if (Message.id >= 40960 && Message.id <= 45055) {
      GRP = 1;
    } else if (Message.id >= 45056 && Message.id <= 49151) {
      GRP = 2;
    } else if (Message.id >= 49152 && Message.id <= 53247) {
      GRP = 3;
    } else if (Message.id >= 53248 && Message.id <= 57343) {
      GRP = 4;
    } else if (Message.id >= 57344) {
      GRP = 5;
    }
    if (mark) {
      switch (GRP) {
        case 1: {
            return'R';
            break;
          }
        case 2: {
            return'G';
            break;
          }
        case 3: {
            return'B';
            break;
          }
        case 4: {
            return'Y';
            break;
          }
        case 5: {
            return'H';
            break;
          }
      }
    } else {
      if (flag) {
        switch (GRP) {
          case 1: {
              display.println("CLAN: FLAME");
              break;
            }
          case 2: {
              display.println("CLAN: GRASS");
              break;
            }
          case 3: {
              display.println("CLAN: WATER");
              break;
            }
          case 4: {
              display.println("CLAN: EARTH");
              break;
            }
          case 5: {
              display.println("CLAN: HYDRA");
              break;
            }
        }
      } else if (latch) {
        switch (GRP) {
          case 1: {
              if ((millis() - now) >= 40 && tick) {
                intensity++;
                if (intensity == 50) {
                  tick = false;
                }
                pixel.setPixelColor(0, intensity, 0, 0);
                pixel.show();
                now = millis();
              } else if ((millis() - now) >= 20 && !tick) {
                intensity--;
                if (intensity == 0) {
                  tick = true;
                }
                pixel.setPixelColor(0, intensity, 0, 0);
                pixel.show();
                now = millis();
              }
              break;
            }
          case 2: {
              if ((millis() - now) >= 40 && tick) {
                intensity++;
                if (intensity == 50) {
                  tick = false;
                }
                pixel.setPixelColor(0, 0, intensity, 0);
                pixel.show();
                now = millis();
              } else if ((millis() - now) >= 20 && !tick) {
                intensity--;
                if (intensity == 0) {
                  tick = true;
                }
                pixel.setPixelColor(0, 0, intensity, 0);
                pixel.show();
                now = millis();
              }
              break;
            }
          case 3: {
              if ((millis() - now) >= 40 && tick) {
                intensity++;
                if (intensity == 50) {
                  tick = false;
                }
                pixel.setPixelColor(0, 0, 0, intensity);
                pixel.show();
                now = millis();
              } else if ((millis() - now) >= 20 && !tick) {
                intensity--;
                if (intensity == 0) {
                  tick = true;
                }
                pixel.setPixelColor(0, 0, 0, intensity);
                pixel.show();
                now = millis();
              }
              break;
            }
          case 4: {
              if ((millis() - now) >= 40 && tick) {
                intensity++;
                if (intensity == 50) {
                  tick = false;
                }
                pixel.setPixelColor(0, intensity, intensity, 0);
                pixel.show();
                now = millis();
              } else if ((millis() - now) >= 20 && !tick) {
                intensity--;
                if (intensity == 0) {
                  tick = true;
                }
                pixel.setPixelColor(0, intensity, intensity, 0);
                pixel.show();
                now = millis();
              }
              break;
            }
          case 5: {
              if ((millis() - now) >= 40 && tick) {
                intensity++;
                if (intensity == 50) {
                  tick = false;
                }
                pixel.setPixelColor(0, intensity, 0, intensity);
                pixel.show();
                now = millis();
              } else if ((millis() - now) >= 20 && !tick) {
                intensity--;
                if (intensity == 0) {
                  tick = true;
                }
                pixel.setPixelColor(0, intensity, 0, intensity);
                pixel.show();
                now = millis();
              }
              break;
            }
        }
      } else {
        pixel.setPixelColor(0, 0, 0, 0);
        pixel.show();
      }
    }
    return 'N';
  }
}
