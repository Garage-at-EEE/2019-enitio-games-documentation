/*  enums_ENITIO.h

    This header file contains enumeration of all IR codes used in ENITIO, and provide
    functions to simplify IR usage in Navitas and games.
*/

#ifndef enums_ENITIO_h
#define enums_ENITIO_h


// OG Colors. Use the first hex character (4 bits). Leave the rest zero.
typedef enum {
  _RED    = 0xA000,
  _BLUE   = 0xB000,
  _YELLOW = 0xC000,
  _GREEN  = 0xD000,
  _BOSS   = 0xE000
} og_color;
typedef enum {
  _DEMOCRAZY    = 0xA00,
  _TICTACWORD   = 0xB00,
  _SWITCH  = 0xC00,
  _PIANO   = 0xD00,
  _ESCAPE = 0xE00,
  _BONUS = 0xF00,
  _ROOF = 0x1000
} game_identifier;
// For games, use the second hex character for identifier.
// Leave the first character zero.

// General navitas actions.
typedef enum {
  NAVITAS_CLAIM = 0x10000000,    // This is 16777216 in hexadecimal.
  NAVITAS_ATTACK = 0x11000000,
  NAVITAS_KILL = 0x12000000,
  NAVITAS_DESTROY = 0x13000000
                    //ADD_MORE_HERE,
                    //ADD_SOME_MORE
} navitas;


// // Switch!
// typedef enum{
//     SWITCH_ATTACK = 0x20000000,
//     SWITCH_CHARGE = 0x21000000
// } game_switch;


// // Democrazy
// typedef enum{
//     DEMOCRAZY_FRONT = 0x00000030,
//     DEMOCRAZY_BACK,
//     DEMOCRAZY_LEFT,
//     DEMOCRAZY_RIGHT,
//     DEMOCRAZY_STOP,
//     DEMOCRAZY_RESUME
// } game_democrazy;


// Towers
typedef enum {
  TOWERS_HEAL = 0x20000000,
  TOWERS_CHARGE = 0x21000000,
  TOWERS_KILL = 0x22000000
} towers;


// // Box in a box in a box
// typedef enum{
//     BOX_LEFT = 0x05000000,
//     BOX_RIGHT
// } game_box;

// Can add more enumerations here. Give first number: 0x06000000.

#endif     // For #ifndef enums_ENITIO_h.
